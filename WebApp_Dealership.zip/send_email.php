<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../autoload.php';  // Adjust the path to autoload.php if necessary

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $source = $_POST['source'];
    $text = $_POST['text'];

    if (empty($name) || empty($email) || empty($phone) || empty($source) || empty($text)) {
        echo "All fields are required.";
        exit;
    }

    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->SMTPDebug = 2;
        $mail->isSMTP();
        $mail->Host       = 'smtp.directstreamone.com';//getenv('SMTP_HOST');directstreamone.com
        $mail->SMTPAuth   = true;
        $mail->Username   = 'team@directstreamone.com';//getenv('SMTP_USERNAME');
        $mail->Password   = 'r&DsRB1N0HwD';//getenv('SMTP_PASSWORD');
        $mail->SMTPSecure = 'ssl';
        $mail->Port       = '465';//getenv('SMTP_PORT');
        
        // Recipients
        $mail->setFrom('team@directstreamone.com', 'Support Team');//getenv('SMTP_USERNAME')
        $mail->addAddress('team@directstreamone.com', 'Usama User');

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'New Contact Form Submission';
        $mail->Body    = "<html><body>
                          <h2>Contact Form Submission</h2>
                          <p><strong>Name:</strong> " . htmlspecialchars($name) . "</p>
                          <p><strong>Email:</strong> " . htmlspecialchars($email) . "</p>
                          <p><strong>Phone:</strong> " . htmlspecialchars($phone) . "</p>
                          <p><strong>Source:</strong> " . htmlspecialchars($source) . "</p>
                          <p><strong>Message:</strong> " . nl2br(htmlspecialchars($text)) . "</p>
                          </body></html>";
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

        $mail->send();
        echo 'Email has been sent';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>
